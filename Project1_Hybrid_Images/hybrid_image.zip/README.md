## CS5670 Assignment 1 -- jl3949

Left image (Josh): low pass with kernel sigma 4.5 and kernel size 13
Right image (Karan): high pass with kernel sigma 4.7 and kernel size 9
Mix-in ratio: 0.65